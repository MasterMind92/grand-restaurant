import clsx from "clsx";

interface params {
    text:string,
    isActive:boolean
};

export function Button({text,isActive}:params){

    let base = "px-4 py-2 max-w-[200px] w-[150px] transition-all hover:text-teal-500 hover:bg-white";

    return (
        <>
            <button 
            className={clsx(
                base,
                {
                    "bg-teal-500 text-white":isActive,
                    "bg-gray-700 text-white":!isActive
                }
            )}
           
            >
                {text}
            </button>
        </>
    );
}