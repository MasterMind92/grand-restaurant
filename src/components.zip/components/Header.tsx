export function Header(){
    
    return (
        <header id="header" className="bg-teal-400 py-4  "> 
            <div className="max-w-3xl flex justify-between mx-auto">
            <div id="logo">
                <span className="font-bold text-4xl text-white ">Logo</span>
            </div>
            
            <div id="menu">
                <div className="flex justify-center w-auto">
                    <button className="py-3 px-6 
                    block bg-white 
                    text-teal-700 font-medium 
                    hover:bg-teal-800 hover:text-white"
                    >
                        Menu
                    </button>
                    <button className="py-3 px-6 
                    mx-4 block bg-white 
                    text-teal-700 font-medium 
                    hover:bg-teal-800 hover:text-white"
                    >
                        Menu
                    </button>
                    <button className="py-3 px-6 
                    block bg-white 
                    text-teal-700 font-medium 
                    hover:bg-teal-800 hover:text-white"
                    >
                        Menu
                    </button>
                    
                </div>
            </div>
          </div>
      </header>
    );
}